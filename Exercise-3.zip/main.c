#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
int i=0;
struct student
{
int rollno;
char name[100];
float cgpa;
char branch[4];
}student[100],data1,data2;

struct value{
int roll;
int loc;
}value[10];

struct bst{
int no;
    int lca ;
int rca ;
int address;
struct bst* left;
struct bst* right;
}*root,*lc,*rc;

struct bs{
int index;
int address;
}bs[10];

struct bst* createNode(int roll,int loc){
struct bst* newNode = malloc(sizeof(struct bst));
newNode->no= roll;
newNode->left=NULL;
newNode->right=NULL;
newNode->lca=-1;
newNode->rca=-1;
newNode->address=loc;
}

char *randstring() {
    static char charset[] = "abcdefghijklmnopqrstuvwxy";
    char *randomString = NULL;

 {
        randomString = malloc(sizeof(char) * (10 +1));

        if (randomString) {
            for (int n = 0;n < 10;n++) {
                int key = rand() % (int)(sizeof(charset) -1);
                randomString[n] = charset[key];
            }

            randomString[11] = '\0';
        }
    }

    return randomString;
}



int add_record()
{
FILE *fp, *index;
int n;
fp=fopen("student_record.txt","a+");
//index=fopen("index.txt","a+");
printf("enter the number of students to insert :");
scanf("%d",&n);
for(int i=0;i<n;i++){
student[i].rollno=rand()%100;
strcpy(student[i].name,randstring());
student[i].cgpa=10;
strcpy(student[i].branch,"cse");
printf("%d %s %f %s\n",student[i].rollno,student[i].name,student[i].cgpa,
student[i].branch);
}
fclose(fp);

return 0;
}

void create_index_file()
{
FILE *fp, *fn;
int roll;
long int loc;
char in ='0';

fp=fopen("student_record.txt","r");
fn=fopen("index_record.txt","w");

for(int j=0;j<10;j++)
{

fscanf(fp, "%d ",&student[j].rollno);
loc=j*28;
fprintf(fn,"%d %d\n",value[j].roll,value[j].loc);

}
}
struct bst* insert(struct bst* root,int roll,int loc)
{
if(root==NULL)
return createNode(roll,loc);
if(roll<root->no)
root->left= insert(root->left,roll,loc);
else if(roll>root->no)
root->right=insert(root->right,roll,loc);
return root;
}

void inorder(struct bst *root, FILE *fi) {
  if(root!=NULL) {

    inorder(root->left, fi);
    value[i].roll=root->no;
    value[i].loc=root->address;
    fprintf(fi,"%d %d\n",value[i].roll,value[i].loc);
    i++;
    inorder(root->right, fi);
  }
}

void index_bst(struct bst *root) {
  FILE *fi;
  fi=fopen("index_bst.txt","w");

  inorder(root, fi);

  fclose(fi);
}

void search()
{
FILE *in,*on;
in=fopen("index_bst.txt","r");
on=fopen("student_record.txt","r");
int rollno;
int loc;
printf("Enter the roll no you want to search");
scanf("%d",&rollno);
for(int i=0;i<10;i++)
{
fscanf(in,"%d %d",&value[i].roll,&value[i].loc);
if(rollno==value[i].roll)
{
loc=value[i].loc;
fseek(on,loc,SEEK_SET);
printf("Rollno:%d\nName:%s\nCGPA:%f\nBranch:%s\n",student[loc/28].rollno,student[loc/28].name,student[loc/28].cgpa,student[i].branch);
break;
}

}
}
void deletion()
{

FILE *index, *fp,*file,*fi;
int rollno;
index=fopen("index_record.txt","w");
fp=fopen("index.txt","w");
file=fopen("student_record.txt","r");
fi=fopen("student.txt","w");
printf("Enter the roll no you want to delete");
scanf("%d",&rollno);
for(int i=0;i<10;i++)
{
fscanf(index,"%d",&value[i].roll);
if(rollno!=value[i].roll)

{
fprintf(fp,"%d %d\n",value[i].roll,value[i].loc);
fprintf(fi,"%d %s %f %s\n",student[i].rollno,student[i].name,student[i].cgpa,
student[i].branch);
}
}
remove("index_record.txt");
rename("index.txt","index_record.txt");
remove("student_record.txt");
rename("student.txt","student_record.txt");

}
int main()
{
add_record();
create_index_file();
struct bst *root =NULL;
FILE *fo;
fo=fopen("index_record.txt","r");
fscanf(fo, "%d ",&student[0].rollno);
root =insert(root,student[0].rollno,0);
for(int i=1;i<10;i++)

{
fscanf(fo, "%d ",&student[i].rollno);
insert(root,student[i].rollno,i*28);

}

index_bst(root);
fclose(fo);
clock_t begin = clock();

search();

clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("time taken : %f",time_spent);
clock_t beg = clock();

deletion();

clock_t endtime = clock();
double time_spend = (double)(endtime - beg) / CLOCKS_PER_SEC;
printf("time taken : %f",time_spend);

struct bst *root2 =NULL;
FILE *fm;
fm=fopen("index_record.txt","r");
fscanf(fo, "%d ",&student[0].rollno);
root2 =insert(root2,student[0].rollno,0);
for(int i=1;i<10;i++)

{
fscanf(fm, "%d ",&student[i].rollno);
insert(root2,student[i].rollno,i*28);

}

index_bst(root2);

return 0;
}


